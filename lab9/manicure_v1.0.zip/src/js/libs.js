//= libs/jquery.min.js
//= libs/jquery.magnific-popup.min.js
//= libs/swiper.jquery.min.js
//= libs/masked-input.min.js
//= libs/jquery.validate.min.js