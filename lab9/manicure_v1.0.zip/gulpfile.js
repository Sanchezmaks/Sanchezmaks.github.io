var gulp = require('gulp'),
	sass = require('gulp-sass'),
	postcss = require('gulp-postcss'),
	autoprefixer = require('autoprefixer'),
	mqpacker = require('css-mqpacker'),
	sourcemaps = require('gulp-sourcemaps'),
	imagemin = require('gulp-imagemin'),
	browserSync = require('browser-sync'),
	clean = require('gulp-clean'),
	rigger = require('gulp-rigger'),
	watch = require('gulp-watch'),
	spritesmith = require('gulp.spritesmith'),
	changed = require('gulp-changed'),
	imageminJpegRecompress = require('imagemin-jpeg-recompress');
	
	//svgSprite = require('gulp-svg-sprite'),
	//gulpFilter = require('gulp-filter'),
	//svg2png = require('gulp-svg2png'),
		
	//uglify = require('gulp-uglify'),
	//concat = require('gulp-concat'),
	//rename = require("gulp-rename"),
	
	reload = browserSync.reload;

var path = {
    build: {
        html: 'build/',
        js: 'build/js/',
        jsLibs: 'build/js/partials',
        css: 'build/css/',
        img: 'build/img/',
        svg: 'build/img/svg',
        icons: 'build/img/icons',
        fonts: 'build/fonts/'
    },
    src: {
        html: 'src/*.{html,php}',
        js: 'src/js/**/*.js',
        sass: 'src/sass/styles.scss',
        img: 'src/img/**/*.*',
        svg: 'src/svg/*.svg',
        icons: 'src/img/icons/*.png',
        fonts: 'src/fonts/**/*.*'
    },
    watch: {
        html: 'src/**/*.{html,php}',
        js: 'src/js/**/*.js',
        sass: 'src/sass/**/*.scss',
        img: 'src/img/**/*.*',
        svg: 'src/svg/*.svg',
        icons: 'src/img/icons/*.png',
        fonts: 'src/fonts/**/*.*'
    },
    clean: './build'
};

var config = {
    server: {
        baseDir: "./build"
    },
    tunnel: false,
    host: 'localhost',
    port: 9000,
    logPrefix: "Frontend_Devil"
};

gulp.task('webserver', function () {
    browserSync(config);
});

gulp.task('clean', function (cb) {
    return gulp.src(path.clean, {read: false})
	.pipe(clean());
});

gulp.task('copycss', function() {
    gulp.src(path.src.css)
    .pipe(gulp.dest(path.build.css));
})

gulp.task('js:build', function () {
    gulp.src(path.src.js) 
        .pipe(rigger()) 
        //.pipe(sourcemaps.init()) 
        //.pipe(uglify()) 
        //.pipe(sourcemaps.wborite()) 
        .pipe(gulp.dest(path.build.js))
        .pipe(reload({stream: true}));
});

gulp.task('sass:build', function () {
	var processors = [
			autoprefixer({browsers: ['last 10 versions'], cascade: false}),
			mqpacker({sort: function (a, b) {
                a = a.replace(/\D/g,'');
                b = b.replace(/\D/g,'');
                return b-a;
            }})
		];
    gulp.src(path.src.sass) 
        .pipe(sourcemaps.init())
        .pipe(sass({
            outputStyle: 'expanded',
			indentWidth: '4',
            sourceMap: true,
        }).on('error', sass.logError))
		//.pipe(cssmin())
		.pipe(postcss(processors))
        .pipe(sourcemaps.write('./'))
        .pipe(gulp.dest(path.build.css))
        .pipe(reload({stream: true}));
});
/*
gulp.task('sprite:build', function() {
    var spriteData = 
        gulp.src(path.src.icons)
            .pipe(spritesmith({
                imgName: 'sprite.png',
                cssName: '_sprite.scss',
                cssFormat: 'scss',
                algorithm: 'binary-tree',
                cssTemplate: 'sass.template.mustache',
                cssVarMap: function(sprite) {
                    sprite.name = sprite.name
                }
            }));

    spriteData.img.pipe(gulp.dest('build/img/'));
    spriteData.css.pipe(gulp.dest('./src/sass/lib/')); 
});
*/
gulp.task('image:build', function () {
    gulp.src(path.src.img) 
		.pipe(changed(path.build.img))
        .pipe(imagemin([
			imagemin.gifsicle(),
			imageminJpegRecompress({
				accurate: true,
				min: 50,
				max: 89,
			}),
			
			imagemin.optipng(),
			imagemin.svgo({removeViewBox: false})
		]))
        .pipe(gulp.dest(path.build.img))
        .pipe(reload({stream: true}));
});

gulp.task('image:copy', function () {
    gulp.src(path.src.img) 
        .pipe(gulp.dest(path.build.img))
});

gulp.task('svg:build', function () {
    gulp.src(path.src.svg) 
        .pipe(gulp.dest(path.build.svg))
        .pipe(reload({stream: true}));
});

gulp.task('fonts:build', function() {
    gulp.src(path.src.fonts)
        .pipe(gulp.dest(path.build.fonts))
});
	
gulp.task('html:build', function () {
    gulp.src(path.src.html) 
        .pipe(rigger())
        .pipe(gulp.dest(path.build.html))
        .pipe(reload({stream: true}));
});

gulp.task('build', [
    'html:build',
    'js:build',
    'sass:build',
    'fonts:build',
    'image:build',
    'svg:build'
]);

gulp.task('watch', function(){
    watch([path.watch.sass], function(event, cb) {
        gulp.start('sass:build');
    });
	/*
    watch([path.watch.icons], function(event, cb) {
        gulp.start('sprite:build');
    });
*/
    watch([path.watch.js], function(event, cb) {
        gulp.start('js:build');
    });
    watch([path.watch.img], function(event, cb) {
        gulp.start('image:build');
    });
    watch([path.watch.svg], function(event, cb) {
        gulp.start('svg:build');
    }); 
    watch([path.watch.fonts], function(event, cb) {
        gulp.start('fonts:build');
    });
    watch([path.watch.html], function(event, cb) {
        gulp.start('html:build');
    });
});

gulp.task('default', ['build', 'webserver', 'watch']);